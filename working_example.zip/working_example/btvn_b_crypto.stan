//BTVN-B model for cryptocurrency dataset. 

functions {                                                                                                                           
                                                                                                                                      
   matrix rho_to_beta_matrix(vector x, vector y, int M) {                                                                               
    matrix[M,M] beta_m;                                                                                                                
    vector[M] y_inv = inv(y);
                                                                                                                              
    for (i in 1:M) {                                                                                                                   
       beta_m[i,i] = 0;                                                                                                                
    }                                                                                                                                  
                                                                                                                                       
    for (i in 2:M) {                                                                                                                   
       for (j in 1:(i-1)) {                                                                                                            
         beta_m[i,j] = x[j+((i-1)*(i-2))/2] *  y[j] * y_inv[i];                                                                           
      }                                                                                                                                
    }                                                                                                                                  
                                                                                                                                       
    for (i in 2:M) {                                                                                                                   
       for (j in 1:(i-1)) {                                                                                                            
         beta_m[j,i] = x[j+((i-1)*(i-2))/2] * y[i] * y_inv[j];                                                                           
      }                                                                                                                                
    }                                                                                                                                  
    return beta_m;                                                                                                                     
  }                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
  real partial_rho_normal(array[] vector rho_slice, int start, int end, array[] vector rho, real epsilon) {                            
                                                                                                                                  
                                                                                                                                       
     if ( end == 1) {                                                                                                                  
        return 0;                                          //no prior state to compare the first time point                            
     }                                                                                                                                 
                                                                                                                                       
     else if ( start == 1) {                                                                                                           
        real lp = 0;                                                                                                                   
                                                                                                                                       
        for (i in 2:(end-start+1)){                                                                                                      
           lp += normal_lpdf(rho_slice[i] | rho[i-1], epsilon);                                                                        
        }                                                                                                                              
                                                                                                                                       
       return lp;                                         //if starting from the begining, regular random walk prior                   
     }                                                                                                                                 
                                                                                                                                       
     else{                                                                                                                             
                                                                                                                                       
        real lp = 0;                                                                                                                      
                                                                                                                                  
        for (i in 1:(end-start+1)){                                                                                                         
           int index = i + start - 1;                                                                                                      
           lp += normal_lpdf(rho_slice[i] | rho[index-1], epsilon);                                                                        
        }
        return lp;                                                                                                                                 
     }
                                                                                                                                 
  }                                                                                                                                    
                                                                                                                                                                                                                                                                            
}
                                                                                                                                      
data {          
  int<lower=2> T;  //number of time points                                                                                                                      
  array[T] int<lower=1> N;  //observations                                                                                                      
  int<lower=1> M;  //number of covariates                                                                                              
                                                                                              
  matrix[N[1],M] elet1;  //the data stored as an array cannot have varying dimension, hence it is hard coded
  matrix[N[2],M] elet2;
  matrix[N[3],M] elet3;
  matrix[N[4],M] elet4;
  matrix[N[5],M] elet5;
  matrix[N[6],M] elet6;
  matrix[N[7],M] elet7;
  matrix[N[8],M] elet8;
  matrix[N[9],M] elet9;
  matrix[N[10],M] elet10;
  matrix[N[11],M] elet11;
  matrix[N[12],M] elet12;
  matrix[N[13],M] elet13;
  matrix[N[14],M] elet14;
  matrix[N[15],M] elet15;
  matrix[N[16],M] elet16;
  matrix[N[17],M] elet17;
  matrix[N[18],M] elet18;
  matrix[N[19],M] elet19;
  matrix[N[20],M] elet20;
  matrix[N[21],M] elet21;
  matrix[N[22],M] elet22;
  matrix[N[23],M] elet23;
  matrix[N[24],M] elet24;
  matrix[N[25],M] elet25;
  matrix[N[26],M] elet26;
  matrix[N[27],M] elet27;
  matrix[N[28],M] elet28;
  matrix[N[29],M] elet29;
  matrix[N[30],M] elet30;
                                                                                     
  real<lower=0,upper=1> theta; //weight of the special group                                                                                                                               
 }  

transformed data{

  real alpha = 0;
}                                                                                                                                    
                                                                                                                                       
parameters {                                                                                                                           
  array[T] vector<lower=-1,upper=1>[(M*(M-1))/2] rho_l;                                                   
                                                                                                                                       
  array[T] vector<lower=0>[M] sigma;                                                        
                                                                                                                                       
  array[T] real<lower=0> epsilon; //adaptive sparseness param                                                                                  
  
  real<lower=0> lambda; //joint smoothness param                                                                                      
                                                                                                                                       
}                                                                                                                                      
                                                                                                                                       
model { 
  matrix[T,M] lp1;                                                                                                                             
  array[T] matrix[M,M] beta_m;

  for (t in 1:T) {
     beta_m[t] = rho_to_beta_matrix(rho_l[t], sigma[t], M);
  }  
                                                                                                                                     
  epsilon ~ exponential(20); 

  target += log_sum_exp( log1m(theta) + exponential_lpdf(lambda | T), log(theta) + exponential_lpdf(lambda | 1) ); 
                                                                                                                                
  //for (t in 1:T) {                                                                                                                     
  //   sigma[t] ~ exponential(1);                                                                             
  //}
  //extra shrinkage to the diagonal
  for (t in 1:T) {                                                                                                                     
      sigma[t] ~ normal(2,1); // joint prior                                                                            
  }                                                                                                                                    
                                                                                                                                       
  for (t in 1:T) {                                                                                                                     
     target += log_sum_exp( log1m(theta) + cauchy_lpdf(rho_l[t] | 0, epsilon[t]), log(theta) + normal_lpdf( rho_l[t] | 0, 0.5 ) );                                                                  
  }                                                                                                                                    
                                                                                                                                       
  target += reduce_sum (partial_rho_normal, rho_l, 5, rho_l, lambda);                                                                  
  
  //again, the likelihood has to be hard coded                                                                                                                                      
  for (i in 1:M){
      lp1[1,i] = normal_id_glm_lpdf( elet1[:,i]  | elet1,  alpha, beta_m[1,:,i],  inv(sigma[1,i])  );
      lp1[2,i] = normal_id_glm_lpdf( elet2[:,i]  | elet2,  alpha, beta_m[2,:,i],  inv(sigma[2,i])  );
      lp1[3,i] = normal_id_glm_lpdf( elet3[:,i]  | elet3,  alpha, beta_m[3,:,i],  inv(sigma[3,i])  );
      lp1[4,i] = normal_id_glm_lpdf( elet4[:,i]  | elet4,  alpha, beta_m[4,:,i],  inv(sigma[4,i])  );
      lp1[5,i] = normal_id_glm_lpdf( elet5[:,i]  | elet5,  alpha, beta_m[5,:,i],  inv(sigma[5,i])  );
      lp1[6,i] = normal_id_glm_lpdf( elet6[:,i]  | elet6,  alpha, beta_m[6,:,i],  inv(sigma[6,i])  );
      lp1[7,i] = normal_id_glm_lpdf( elet7[:,i]  | elet7,  alpha, beta_m[7,:,i],  inv(sigma[7,i])  );
      lp1[8,i] = normal_id_glm_lpdf( elet8[:,i]  | elet8,  alpha, beta_m[8,:,i],  inv(sigma[8,i])  );
      lp1[9,i] = normal_id_glm_lpdf( elet9[:,i]  | elet9,  alpha, beta_m[9,:,i],  inv(sigma[9,i])  );
      lp1[10,i]= normal_id_glm_lpdf( elet10[:,i] | elet10, alpha, beta_m[10,:,i], inv(sigma[10,i]) );
      lp1[11,i]= normal_id_glm_lpdf( elet11[:,i] | elet11, alpha, beta_m[11,:,i], inv(sigma[11,i]) );
      lp1[12,i]= normal_id_glm_lpdf( elet12[:,i] | elet12, alpha, beta_m[12,:,i], inv(sigma[12,i]) );
      lp1[13,i]= normal_id_glm_lpdf( elet13[:,i] | elet13, alpha, beta_m[13,:,i], inv(sigma[13,i]) );
      lp1[14,i]= normal_id_glm_lpdf( elet14[:,i] | elet14, alpha, beta_m[14,:,i], inv(sigma[14,i]) );
      lp1[15,i]= normal_id_glm_lpdf( elet15[:,i] | elet15, alpha, beta_m[15,:,i], inv(sigma[15,i]) );
      lp1[16,i]= normal_id_glm_lpdf( elet16[:,i] | elet16, alpha, beta_m[16,:,i], inv(sigma[16,i]) );
      lp1[17,i]= normal_id_glm_lpdf( elet17[:,i] | elet17, alpha, beta_m[17,:,i], inv(sigma[17,i]) );
      lp1[18,i]= normal_id_glm_lpdf( elet18[:,i] | elet18, alpha, beta_m[18,:,i], inv(sigma[18,i]) );
      lp1[19,i]= normal_id_glm_lpdf( elet19[:,i] | elet19, alpha, beta_m[19,:,i], inv(sigma[19,i]) );
      lp1[20,i]= normal_id_glm_lpdf( elet20[:,i] | elet20, alpha, beta_m[20,:,i], inv(sigma[20,i]) );
      lp1[21,i]= normal_id_glm_lpdf( elet21[:,i] | elet21, alpha, beta_m[21,:,i], inv(sigma[21,i]) );
      lp1[22,i]= normal_id_glm_lpdf( elet22[:,i] | elet22, alpha, beta_m[22,:,i], inv(sigma[22,i]) );
      lp1[23,i]= normal_id_glm_lpdf( elet23[:,i] | elet23, alpha, beta_m[23,:,i], inv(sigma[23,i]) );
      lp1[24,i]= normal_id_glm_lpdf( elet24[:,i] | elet24, alpha, beta_m[24,:,i], inv(sigma[24,i]) );
      lp1[25,i]= normal_id_glm_lpdf( elet25[:,i] | elet25, alpha, beta_m[25,:,i], inv(sigma[25,i]) );
      lp1[26,i]= normal_id_glm_lpdf( elet26[:,i] | elet26, alpha, beta_m[26,:,i], inv(sigma[26,i]) );
      lp1[27,i]= normal_id_glm_lpdf( elet27[:,i] | elet27, alpha, beta_m[27,:,i], inv(sigma[27,i]) );
      lp1[28,i]= normal_id_glm_lpdf( elet28[:,i] | elet28, alpha, beta_m[28,:,i], inv(sigma[28,i]) );
      lp1[29,i]= normal_id_glm_lpdf( elet29[:,i] | elet29, alpha, beta_m[29,:,i], inv(sigma[29,i]) );
      lp1[30,i]= normal_id_glm_lpdf( elet30[:,i] | elet30, alpha, beta_m[30,:,i], inv(sigma[30,i]) );
   }  
   target += sum(lp1);                                                                                                                  
}                                                                                                                                      
                                                                                                                                       

