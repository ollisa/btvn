#This R script contains the steps for recreating the empirical analysis section in our paper.
#Rtools is required for Windows PCs.

#Please, add the *working_example* folder to your working directory.

#Installation of cmdstanr following https://mc-stan.org/cmdstanr/articles/cmdstanr.html

install.packages("cmdstanr", repos = c('https://stan-dev.r-universe.dev', getOption("repos")))

library(cmdstanr)
check_cmdstan_toolchain()
install_cmdstan(cores = 2)

#Code for testing the installation is also available at the aforementioned website.


#Other packages used in this example

#The package quantmod is used for loading the data from Yahoo finance.
if(!require(quantmod)){
  install.packages("quantmod")
  library(quantmod)
}

#The package igraph is used for plotting the networks and for inferring the communities
if(!require(igraph)){
  install.packages("igraph")
  library(igraph)
}

#Functions for network selection are included in the *working_example* folder
source("./working_example/btvn_functions.R")

#Coordinates for plotting are taken from a monthly estimate. They are available in the coords2.2.RDS
coords2.2 <- readRDS("./working_example/coords2.2.RDS")

#Optionally, the network estimates are also available in the *working_example* folder
#network_monthly <- readRDS("./working_example/network_monthly.RDS")
#network_whole <- readRDS("./working_example/network_whole.RDS")


#Loading the data and creating Stan compatible data files.

#We are considering the closing prices of the following cryptocurrencies in USD for a 30 month period from 2022-01-01 to 2024-06-30.
#These can be obtained as follows:

cryptocurrencies = c("BTC", "WBTC", "WSTETH", "ETH", "STETH", "WETH", "BNB", "BCH", "SOL", "LTC", 
                     "AVAX", "LINK", "LEO", "TON11419", "NEAR", "DOT", "USDC", "DAI", "USDT", "XRP")

cryptocurrencies = paste0(cryptocurrencies, "-USD")

Data = c()
for(cr in cryptocurrencies){
  
  A = list(Symbols = cr, 
           auto.assign = FALSE, 
           from = "2022-01-01",
           to = "2024-06-30")
  
  a = do.call("getSymbols", A)
  
  Data = cbind(Data, a[, 4]) # Closing prices
  
}

#Next, we list the data by month. The data is normalized either by month or for the whole 30 month period.
#For this, we use the provided function.

#monthly
crypto_data_list_monthly <- create_list_by_month2(Data,c(2022,2023,2024),
                                                  list(c("01","02","03","04","05","06","07","08","09",10,11,12),
                                                       c("01","02","03","04","05","06","07","08","09",10,11,12),
                                                       c("01","02","03","04","05","06")), scale = T)
#whole period
crypto_data_list_whole <- create_list_by_month2(scale(Data),c(2022,2023,2024),
                                                  list(c("01","02","03","04","05","06","07","08","09",10,11,12),
                                                       c("01","02","03","04","05","06","07","08","09",10,11,12),
                                                       c("01","02","03","04","05","06")), scale = F)

#The difference between normalization methods is clearly evident
par(mfrow=c(1,2))
ts.plot(crypto_data_list_monthly[[1]])
ts.plot(crypto_data_list_whole[[1]])

#Additionally, we save the sample sizes as a vector.
sample_sizes <- c()
for (i in 1:30) {
  sample_sizes[i] <- dim(crypto_data_list_monthly[[i]])[[1]]
}

#Since Stan does not support array of datasets with varying dimensions, here we have hard coded the datasets.
#The variable theta is the weight of the special group, given by 0.1*20/((20*19)/2).

data_crypto_monthly <- list( T=30, N=sample_sizes, M=20, 
                             elet1 =as.matrix(crypto_data_list_monthly[[1]]),
                             elet2 =as.matrix(crypto_data_list_monthly[[2]]),
                             elet3 =as.matrix(crypto_data_list_monthly[[3]]),
                             elet4 =as.matrix(crypto_data_list_monthly[[4]]),
                             elet5 =as.matrix(crypto_data_list_monthly[[5]]),
                             elet6 =as.matrix(crypto_data_list_monthly[[6]]),
                             elet7 =as.matrix(crypto_data_list_monthly[[7]]),
                             elet8 =as.matrix(crypto_data_list_monthly[[8]]),
                             elet9 =as.matrix(crypto_data_list_monthly[[9]]),
                             elet10=as.matrix(crypto_data_list_monthly[[10]]),
                             elet11=as.matrix(crypto_data_list_monthly[[11]]),
                             elet12=as.matrix(crypto_data_list_monthly[[12]]),
                             elet13=as.matrix(crypto_data_list_monthly[[13]]),
                             elet14=as.matrix(crypto_data_list_monthly[[14]]),
                             elet15=as.matrix(crypto_data_list_monthly[[15]]),
                             elet16=as.matrix(crypto_data_list_monthly[[16]]),
                             elet17=as.matrix(crypto_data_list_monthly[[17]]),
                             elet18=as.matrix(crypto_data_list_monthly[[18]]),
                             elet19=as.matrix(crypto_data_list_monthly[[19]]),
                             elet20=as.matrix(crypto_data_list_monthly[[20]]),
                             elet21=as.matrix(crypto_data_list_monthly[[21]]),
                             elet22=as.matrix(crypto_data_list_monthly[[22]]),
                             elet23=as.matrix(crypto_data_list_monthly[[23]]),
                             elet24=as.matrix(crypto_data_list_monthly[[24]]),
                             elet25=as.matrix(crypto_data_list_monthly[[25]]),
                             elet26=as.matrix(crypto_data_list_monthly[[26]]),
                             elet27=as.matrix(crypto_data_list_monthly[[27]]),
                             elet28=as.matrix(crypto_data_list_monthly[[28]]),
                             elet29=as.matrix(crypto_data_list_monthly[[29]]),
                             elet30=as.matrix(crypto_data_list_monthly[[30]]),
                             theta=0.011)

data_crypto_whole <- list( T=30, N=sample_sizes, M=20, 
                           elet1 =as.matrix(crypto_data_list_whole[[1]]),
                           elet2 =as.matrix(crypto_data_list_whole[[2]]),
                           elet3 =as.matrix(crypto_data_list_whole[[3]]),
                           elet4 =as.matrix(crypto_data_list_whole[[4]]),
                           elet5 =as.matrix(crypto_data_list_whole[[5]]),
                           elet6 =as.matrix(crypto_data_list_whole[[6]]),
                           elet7 =as.matrix(crypto_data_list_whole[[7]]),
                           elet8 =as.matrix(crypto_data_list_whole[[8]]),
                           elet9 =as.matrix(crypto_data_list_whole[[9]]),
                           elet10=as.matrix(crypto_data_list_whole[[10]]),
                           elet11=as.matrix(crypto_data_list_whole[[11]]),
                           elet12=as.matrix(crypto_data_list_whole[[12]]),
                           elet13=as.matrix(crypto_data_list_whole[[13]]),
                           elet14=as.matrix(crypto_data_list_whole[[14]]),
                           elet15=as.matrix(crypto_data_list_whole[[15]]),
                           elet16=as.matrix(crypto_data_list_whole[[16]]),
                           elet17=as.matrix(crypto_data_list_whole[[17]]),
                           elet18=as.matrix(crypto_data_list_whole[[18]]),
                           elet19=as.matrix(crypto_data_list_whole[[19]]),
                           elet20=as.matrix(crypto_data_list_whole[[20]]),
                           elet21=as.matrix(crypto_data_list_whole[[21]]),
                           elet22=as.matrix(crypto_data_list_whole[[22]]),
                           elet23=as.matrix(crypto_data_list_whole[[23]]),
                           elet24=as.matrix(crypto_data_list_whole[[24]]),
                           elet25=as.matrix(crypto_data_list_whole[[25]]),
                           elet26=as.matrix(crypto_data_list_whole[[26]]),
                           elet27=as.matrix(crypto_data_list_whole[[27]]),
                           elet28=as.matrix(crypto_data_list_whole[[28]]),
                           elet29=as.matrix(crypto_data_list_whole[[29]]),
                           elet30=as.matrix(crypto_data_list_whole[[30]]),
                           theta=0.011)

#First, we estimate the BTVN-B model for the monthly-normalized data.
#Before this, the included model can be compiled using 

btvn_b_model_for_cryptocurrency_data <- "./working_example/btvn_b_crypto.stan" 

#compiling the model
compiled_btvn_b_model <- cmdstan_model(btvn_b_model_for_cryptocurrency_data, 
                                   cpp_options = list(stan_threads = TRUE), 
                                   force=TRUE, stanc_options = list("O1"))

#Above, cpp_options = list(stan_threads = TRUE) enables the use of multithreading,
#force=TRUE ensures that the model is compiled,
#and stanc_options = list("O1") enables O1 optimization

#MCMC can be run using
parameter_estimation_monthly <- compiled_btvn_b_model$sample(
  data = data_crypto_monthly,
  seed = 12345,
  chains = 1, 
  parallel_chains = 1,
  threads_per_chain = 2,
  iter_warmup = 500,
  iter_sampling = 1500,
  fixed_param = FALSE,
  adapt_delta = 0.99,
  max_treedepth = 10
)
#For us, the estimation took 2191.5 seconds.

#The adjacency matrix estimates can be obtained based on credible intervals using the provided function
cryptocurrency_network_estimate_monthly <- rho_res_mat_to_adj_list(rho_res_mat = parameter_estimation_monthly, 
                                                            M = 20, n_time_points = 30, credible_level = 0.99)
#However, these can be confirmed to be identical by visually inspecting pairwise differences
par(mfrow=c(5,6))
for (i in 2:30) {
  graph_plot(cryptocurrency_network_estimate_monthly[[i]] - 
             cryptocurrency_network_estimate_monthly[[i]]*cryptocurrency_network_estimate_monthly[[i-1]], coord = coords2.2)
}


#For better visuals, we use igraph for plotting the networks
network_monthly <- graph_from_adjacency_matrix(cryptocurrency_network_estimate_monthly[[1]], 
                                               mode = "undirected", diag = F)

vertex_attr(network_monthly, "name") <- c("BTC", "WBTC", "WSTETH", "ETH", "STETH", "WETH", "BNB", "BCH", "SOL", "LTC",
                                          "AVAX", "LINK", "LEO", "TON11419", "NEAR", "DOT", "USDC", "DAI", "USDT", "XRP")


#The same is then repeated for the data that was normalized for the whole period.
parameter_estimation_whole <- compiled_btvn_b_model$sample(
  data = data_crypto_whole,
  seed = 12345,
  chains = 1, 
  parallel_chains = 1,
  threads_per_chain = 2,
  iter_warmup = 500,
  iter_sampling = 1500,
  fixed_param = FALSE,
  adapt_delta = 0.99,
  max_treedepth = 10
)
#For us, the estimation took 2140.2 seconds.

#Again, the networks estimates can be obtained by running
cryptocurrency_network_estimate_whole <- rho_res_mat_to_adj_list(rho_res_mat = parameter_estimation_whole, 
                                                        M = 20, n_time_points = 30, credible_level = 0.99)

#The individual graphs can be plotted using 
par(mfrow=c(5,6))
for (i in 1:30) {
  graph_plot(cryptocurrency_network_estimate_whole[[i]],coord = coords2.2)
}

#For better visuals, we present the individual network estimates as a single weighted graph.
cryptocurrency_network_cumulative <- cryptocurrency_network_estimate_whole[[1]]
for (i in 2:30) {
  cryptocurrency_network_cumulative  <- cryptocurrency_network_cumulative + cryptocurrency_network_estimate_whole[[i]]
}

#Again, for better visualization, we remove edges that are present only once in the network chain.
cryptocurrency_network_cumulative_g <- cryptocurrency_network_cumulative
cryptocurrency_network_cumulative_g[cryptocurrency_network_cumulative_g<2] <- 0

#For plotting, we again use the igraph network. The elements of the weighted adjacency matrix are divided by 6 for better visualization.
network_whole <- graph_from_adjacency_matrix(cryptocurrency_network_cumulative_g/6, mode = "undirected",diag = F,weighted = TRUE)

vertex_attr(network_whole, "name") <- c("BTC", "WBTC", "WSTETH", "ETH", "STETH", "WETH", "BNB", "BCH", "SOL", "LTC",
                                          "AVAX", "LINK", "LEO", "TON11419", "NEAR", "DOT", "USDC", "DAI", "USDT", "XRP")


#The exact Figure 3 of the paper can be obtained using
pdf("crypto_mix_plot3_v2.pdf",width = 7,height = 2.5)
par(mfrow=c(1,2),mgp = c(2.2, 0.45, 0),tcl = -0.01, mar = c(0.1, 0.1, 0.6, 0.1))

plot(network_monthly, layout=coords2.2, main="", vertex.label.color="black", 
     edge.width=3, vertex.label.dist=1.5, vertex.size=3)

plot(network_whole, layout=coords2.2, main="", vertex.label.color="black", 
     edge.width=igraph::E(network_whole)$weight,vertex.label.dist=1.5,vertex.size=3)
dev.off()


#We can then search for communities in the inferred networks. For this we use the walktrap method from package igraph.
communities_network_monthly   <- igraph::cluster_walktrap(network_monthly)
communities_network_whole <- igraph::cluster_walktrap(network_whole)

#The exact Figure 4 of the paper can be obtained using
pdf("crypto_mix_walktrap_v2.pdf",width = 7,height = 2.5)
par(mfrow=c(1,2),mgp = c(2.2, 0.45, 0),tcl = -0.01, mar = c(0.1, 0.1, 0.6, 0.1))

plot(communities_network_monthly,network_monthly,layout=coords2.2,main="", 
     vertex.label.color="black", edge.width=3,vertex.label.dist=1.5,
     vertex.size=3, edge.color = "gray")

plot(communities_network_whole,network_whole,layout=coords2.2,main="", 
     vertex.label.color="black", edge.width=igraph::E(network_whole)$weight,
     vertex.label.dist=1.5,vertex.size=3,edge.color = "gray")
dev.off()


#Last, the similarity of the found communities can be measured using Rand index. This is implemented in igraph
igraph::compare(igraph::cluster_walktrap(network_monthly),
                igraph::cluster_walktrap(network_whole),
                method = "rand")
#We obtained a Rand index value of 0.7578947

