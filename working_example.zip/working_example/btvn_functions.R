#Functions for edge selection and evaluation of network recovery performance given the simulation data and mcmc samples

#rajat: a function that checks if the crebile interval contains value 0.
rajat <- function(yla,ala){
  arvo <- yla-ala;
  i <- dim(arvo)[1]
  
  for (p in 1:i) {
    for (h in 1:i) {
      if (max(abs(yla[p,h]),abs(ala[p,h]))>abs(arvo[p,h])){
        arvo[p,h] <- 1
      }
      else{
        arvo[p,h] <- 0
      }
    }
  }
  return(arvo)
}

#rho_res_mat_to_adj_list: a function that turns the estimated lower triangular of the partial correlation matrix into a list of adjacency matrices given the crebility level
rho_res_mat_to_adj_list <- function(rho_res_mat, N, M, n_time_points,credible_level){
  
  Al <- list()
  for (i in 1:n_time_points) {
    Al[[i]] <- matrix(0,M,M)
  }
  
  Au <- list()
  for (i in 1:n_time_points) {
    Au[[i]] <- matrix(0,M,M)
  }
  
  A <- list()
  for (i in 1:n_time_points) {
    A[[i]] <- matrix(0,M,M)
  }
  
  res_ql <- matrix(apply(rho_res_mat$draws(variables = "rho_l", format = "matrix"),2, function(x) quantile(x,probs=c(1-credible_level))),nrow = n_time_points)
  
  res_qu <- matrix(apply(rho_res_mat$draws(variables = "rho_l", format = "matrix"),2,function(x) quantile(x,probs=c(credible_level))),nrow=n_time_points)
  
  for (ti in 1:n_time_points) {
    for (i in 2:M) {
      for (j in 1:(i-1)) {
        Al[[ti]][i,j] <- res_ql[ti,(j+(i-1)*(i-2)/2)]
        Al[[ti]][j,i] <- Al[[ti]][i,j]
      }  
    } 
  }
  
  for (ti in 1:n_time_points) {
    for (i in 2:M) {
      for (j in 1:(i-1)) {
        Au[[ti]][i,j] <- res_qu[ti,(j+(i-1)*(i-2)/2)]
        Au[[ti]][j,i] <- Au[[ti]][i,j]
      }  
    } 
  }
  
  for (ti in 1:n_time_points) {
    A[[ti]] <- rajat(Al[[ti]],Au[[ti]])
  }
  
  return(A)
}



#similarity stats: a function that takes the true and estimated adjacency matrix. returns a confusion matrix
similarity_stats <- function(adjecency_T,adjecency_E){
  
  samat <- adjecency_T*adjecency_E
  
  fp <- adjecency_E - samat 
  
  fn <- adjecency_T - samat 
  
  unit <- matrix(1,nrow = dim(adjecency_T)[1],ncol = dim(adjecency_T)[1])
  diag(unit) <- 0
  tn <- ( unit - adjecency_T)*(unit - adjecency_E)
  
  return( matrix(c(sum(samat)/2,sum(fn)/2,sum(fp)/2,sum(tn)/2),2,2,byrow=TRUE))
}


#calculate scores: a function that calculates most of the performance indicators from a given confusion matrix
calculate_scores <- function(cm) {
  tp <- cm[1,1]
  tn <- cm[2,2]
  fp <- cm[2,1]
  fn <- cm[1,2]
  tpr <- tp / (tp + fn)
  tnr <- tn / (tn + fp)
  ppv <- tp / (tp + fp)
  npv <- tn / (tn + fn)
  fnr <- 1 - tpr
  fpr <- 1 - tnr
  fdr <- 1 - ppv
  FOR <- 1 - npv
  lr_plus <- tpr / fpr
  lr_neg <- fnr / tnr
  pt <- sqrt(fpr) / (sqrt(tpr) + sqrt(fpr))
  ts <- tp / (tp + fn + fp)
  acc <- (tp + tn) / (tp + tn + fn + fp)
  bal_acc <- (tpr + tnr) / 2
  F1_score <- 2 * (ppv * tpr) / (ppv + tpr)
  mcc <- (tp * tn - fp * fn) / sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
  results <- data.frame(ACC = acc, ACC_bal = bal_acc, MCC = mcc, F1 = F1_score,
                        TPR = tpr, TNR = tnr, PPV = ppv, NPV = npv, FNR = fnr,
                        FPR = fpr, FOR = FOR, LRp = lr_plus, LRn = lr_neg)
  return(results)
}


#ts_scores: a function that calculates the performance scores for a time chain of estimated networks
ts_scores <- function(true,est,nt){
  scoreboard <- matrix(NA, nt, 13)
  colnames(scoreboard) <- colnames(calculate_scores( similarity_stats(true[[1]],est[[1]])))
  for (i in 1:nt) {
    scoreboard[i,] <- as.matrix(calculate_scores( similarity_stats(true[[i]],est[[i]])))
  }
  return(scoreboard)
}


#draws_mat_to_inv_sigma_list: a function that calculates estiamtes for the precision matrices given the drawn samples
draws_mat_to_inv_sigma_list <- function(draws_mat, N,M,n_time_points) {
  
  Al <- list()
  for (i in 1:n_time_points) {
    Al[[i]] <- matrix(1,M,M)
  }
  Dl <- list()
  for (i in 1:n_time_points) {
    Dl[[i]] <- matrix(0,M,M)
  }
  
  Rl <- list()
  
  
  res_rho <- median(draws_mat$rho_l)
  res_sigma <- median(draws_mat$sigma)
  
  for (ti in 1:n_time_points) {
    for (i in 2:M) {
      for (j in 1:(i-1)) {
        Al[[ti]][i,j] <- -res_rho[ti,(j+(i-1)*(i-2)/2)]
        Al[[ti]][j,i] <- Al[[ti]][i,j]
      }  
    } 
  }
  
  for (ti in 1:n_time_points) {
    diag(Dl[[ti]]) <- (res_sigma[ti,]) 
  }
  
  for (ti in 1:n_time_points) {
    Rl[[ti]] <- Dl[[ti]]%*%Al[[ti]]%*%Dl[[ti]]
  }
  
  
  return(list(Al,Rl))
}

#scores by threshold
adj_list_by_threshold <- function(draws_mat, adj_t_list, N,M,n_time_points, threshold){
  inv_sigma_list <- draws_mat_to_inv_sigma_list(draws_mat, N,M,n_time_points)[[2]]
  
  adj_list <- list()
  
  for (i in 1:n_time_points) {
    temp <- inv_sigma_list[[i]]
    diag(temp) <- 0
    temp[abs(temp)<threshold] <- 0
    temp[temp !=0] <- 1
    
    adj_list[[i]] <- temp
  }
  return(adj_list)
  gc()
}


#stein_loss_result: a function that calculates the stein's loss for the estimated precision matrices given the true covariance matrices
stein_loss_result <- function(true_sigmas, draw_mat, t, p){
  loss <- c()
  est <- draws_mat_to_inv_sigma_list(draw_mat,100,p,t)
  
  for (i in 1:t) {
    loss[i] <- sum(diag((true_sigmas[[i]])%*%est[[2]][[i]])) - log(det((true_sigmas[[i]])%*%est[[2]][[i]])) - p
    
  }
  
  return(loss)
}





#EXPERIMENTAL: for creating the precision matrix estimate for the state-space models
draws_mat_to_inv_sigma_list2 <- function(draws_mat, N,M,n_time_points) {
  
  Al <- list()
  for (i in 1:n_time_points) {
    Al[[i]] <- matrix(1,M,M)
  }
  Dl <- list()
  for (i in 1:n_time_points) {
    Dl[[i]] <- matrix(0,M,M)
  }
  
  Rl <- list()
  
  
  res_rho <- median(draws_mat$rho_l)
  res_sigma_r <- median(draws_mat$sigma_r)
  res_sigma_s <- median(draws_mat$sigma)
  res_sigma <- sqrt(res_sigma_r^2+res_sigma_s^2)
  
  for (ti in 1:n_time_points) {
    for (i in 2:M) {
      for (j in 1:(i-1)) {
        Al[[ti]][i,j] <- -res_rho[ti,(j+(i-1)*(i-2)/2)]
        Al[[ti]][j,i] <- Al[[ti]][i,j]
      }  
    } 
  }
  
  for (ti in 1:n_time_points) {
    diag(Dl[[ti]]) <- (res_sigma[ti,]) 
  }
  
  for (ti in 1:n_time_points) {
    Rl[[ti]] <- Dl[[ti]]%*%Al[[ti]]%*%Dl[[ti]]
  }
  
  
  return(list(Al,Rl))
  gc()
}


#EXPERIMENTAL: for calculating the stein's loss for state-space models
stein_loss_result2 <- function(true_sigmas, draw_mat, t, p){
  loss <- c()
  est <- draws_mat_to_inv_sigma_list2(draw_mat,100,p,t)
  
  for (i in 1:t) {
    loss[i] <- sum(diag((true_sigmas[[i]])%*%est[[2]][[i]])) - log(det((true_sigmas[[i]])%*%est[[2]][[i]])) - p
    
  }
  
  return(loss)
}



#similarity plots: a function for plotting results
similarity_plots <- function(adjecency_T,adjecency_E){
  
  par(mfrow=c(2,2))
  
  samat <- adjecency_T*adjecency_E
  
  network <- graph_from_adjacency_matrix(samat, mode = "undirected",diag = F)
  
  coords<-layout.fruchterman.reingold(network)
  
  plot(network,layout=coords,main="TRUE POSITIVES", vertex.label.color="black", edge.width=3,vertex.label.dist=0.5,vertex.size=3)
  
  fp <- adjecency_E - samat 
  
  network <- graph_from_adjacency_matrix(fp, mode = "undirected",diag = F)
  
  coords<-layout.fruchterman.reingold(network)
  
  # plot it
  plot(network,layout=coords,main="FALSE POSITIVES", vertex.label.color="black", edge.width=3,vertex.label.dist=0.5,vertex.size=3)
  
  fn <- adjecency_T - samat 
  
  network <- graph_from_adjacency_matrix(fn, mode = "undirected",diag = F)
  
  coords<-layout.fruchterman.reingold(network)
  
  # plot it
  plot(network,layout=coords,main="FALSE NEGATIVES", vertex.label.color="black", edge.width=3,vertex.label.dist=0.5,vertex.size=3)
  
  
  
  network <- graph_from_adjacency_matrix(adjecency_T, mode = "undirected",diag = F)
  
  coords<-layout.fruchterman.reingold(network)
  
  # plot it
  plot(network,layout=coords,main="TRUE PLOT", vertex.label.color="black", edge.width=3,vertex.label.dist=0.5,vertex.size=3)
  
  
}

#graph_plot: a simple function that plots a graph based on adjacency matrix. Option to use given coordinates, otherwise plotted using fruchterman.reingold
graph_plot <- function(adj,coord = matrix(NA,dim(adj)[1],2) ) {
  
  network <- graph_from_adjacency_matrix(adj, mode = "undirected",diag = F)
  
  if(is.na(sum(coord))==TRUE){
    coords<-layout.fruchterman.reingold(network)
  } else{
    coords <- coord
  }
  
  plot(network,layout=coords,main="", vertex.label.color="black", edge.width=3,vertex.label.dist=0.5,vertex.size=3)
  
}

#create_list_by_month2: a function for creating a list of data matrices by month from quantmod data. Optionally, the matrices can be scaled columnwise
create_list_by_month2 <- function(x, years, months, scale){
  data_list <- list()
  index = 1
  if (scale==T){
    for (i in years) {
      for (j in months[[match(i,years)]]) {
        data_list[[index]] <- scale(x[grep(paste(i,'-',j,sep = ''), row.names(as.matrix(x))),])
        index = index + 1
      }
    }
  }
  else{
    for (i in years) {
      for (j in months[[match(i,years)]]) {
        data_list[[index]] <- x[grep(paste(i,'-',j,sep = ''), row.names(as.matrix(x))),]
        index = index + 1
      }
    }
  }
  return(data_list)
}
