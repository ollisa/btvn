library(huge)

huge_10_tulos.1 <- list()
huge_10_icov.1 <- list()
huge_10_lambda.1 <- c()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.1[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.1[[i]] <- sel_huge$refit
  huge_10_lambda.1[i] <- sel_huge$opt.lambda
  huge_10_icov.1[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[1]],huge_10_tulos.1,10)


huge_10_tulos.2 <- list()
huge_10_lambda.2 <- c()
huge_10_icov.2 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.2[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.2[[i]] <- sel_huge$refit
  huge_10_lambda.2[i] <- sel_huge$opt.lambda
  huge_10_icov.2[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[2]],huge_10_tulos.2,10)


huge_10_tulos.3 <- list()
huge_10_lambda.3 <- c()
huge_10_icov.3 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.3[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.3[[i]] <- sel_huge$refit
  huge_10_lambda.3[i] <- sel_huge$opt.lambda
  huge_10_icov.3[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[3]],huge_10_tulos.3,10)


huge_10_tulos.4 <- list()
huge_10_lambda.4 <- c()
huge_10_icov.4 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.4[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.4[[i]] <- sel_huge$refit
  huge_10_lambda.4[i] <- sel_huge$opt.lambda
  huge_10_icov.4[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[4]],huge_10_tulos.4,10)



huge_10_tulos.5 <- list()
huge_10_lambda.5 <- c()
huge_10_icov.5 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.5[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.5[[i]] <- sel_huge$refit
  huge_10_lambda.5[i] <- sel_huge$opt.lambda
  huge_10_icov.5[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[5]],huge_10_tulos.5,10)


huge_10_tulos.6 <- list()
huge_10_lambda.6 <- c()
huge_10_icov.6 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.6[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.6[[i]] <- sel_huge$refit
  huge_10_lambda.6[i] <- sel_huge$opt.lambda
  huge_10_icov.6[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[6]],huge_10_tulos.6,10)


huge_10_tulos.7 <- list()
huge_10_lambda.7 <- c()
huge_10_icov.7 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.7[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.7[[i]] <- sel_huge$refit
  huge_10_lambda.7[i] <- sel_huge$opt.lambda
  huge_10_icov.7[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[7]],huge_10_tulos.7,10)


huge_10_tulos.8 <- list()
huge_10_lambda.8 <- c()
huge_10_icov.8 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.8[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.8[[i]] <- sel_huge$refit
  huge_10_lambda.8[i] <- sel_huge$opt.lambda
  huge_10_icov.8[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[8]],huge_10_tulos.8,10)


huge_10_tulos.9 <- list()
huge_10_lambda.9 <- c()
huge_10_icov.9 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.9[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.9[[i]] <- sel_huge$refit
  huge_10_lambda.9[i] <- sel_huge$opt.lambda
  huge_10_icov.9[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[9]],huge_10_tulos.9,10)


huge_10_tulos.10 <- list()
huge_10_lambda.10 <- c()
huge_10_icov.10 <- list()
for(i in 1:10){
  res_huge <- huge::huge(t(ts_sim_data_100p100n.10[[i]]), method = "glasso")
  sel_huge <- huge::huge.select(res_huge,criterion = "stars")
  diag(sel_huge$refit) <- 0
  huge_10_tulos.10[[i]] <- sel_huge$refit
  huge_10_lambda.10[i] <- sel_huge$opt.lambda
  huge_10_icov.10[[i]] <- sel_huge$opt.icov
}

ts_scores(ts_true_data_100p_500n[[10]],huge_10_tulos.10,10)

cum_tulos_huge <- ts_scores(ts_true_data_100p_500n[[1]],huge_10_tulos.1,10)

for(j in 2:10){
  cum_tulos_huge <- rbind(cum_tulos_huge,ts_scores(ts_true_data_100p_500n[[j]],eval(parse(text=paste0("huge_10_tulos.",j))),10))
}

round(RcmdrMisc::numSummary(cum_tulos_huge[,c("MCC","F1","TPR","FPR","PPV")])[[2]],4)




########space
library(space)

l1 = 1/sqrt(100)*qnorm(1-0.1/(2*100^2))


result <- list()
for(i in 1:10){
  result1=space.neighbor(t(eval(parse(text=paste0("ts_sim_data_100p100n.",1)))[[i]]), lam1=l1*0.6, lam2=0)
  fit.adj=abs(result1$ParCor)>1e-6
  fit.adj[fit.adj==1] <- 1
  fit.adj[fit.adj==0] <- 0
  diag(fit.adj) <- 0
  
  result[[i]] <- fit.adj
}
cum_tulos_space <- ts_scores(ts_true_data_100p_500n[[1]],result,10)


for(j in 2:10){
  result <- list()
  for(i in 1:10){
    result1=space.neighbor(t(eval(parse(text=paste0("ts_sim_data_100p100n.",j)))[[i]]), lam1=l1*0.6, lam2=0)
    fit.adj=abs(result1$ParCor)>1e-6
    fit.adj[fit.adj==1] <- 1
    fit.adj[fit.adj==0] <- 0
    diag(fit.adj) <- 0
    
    result[[i]] <- fit.adj
  }
  cum_tulos_space <- rbind(cum_tulos_space,ts_scores(ts_true_data_100p_500n[[j]],result,10))
  
}

cum_tulos_space
RcmdrMisc::numSummary(cum_tulos_space[,c("MCC","F1","TPR","FPR","PPV")])
round(RcmdrMisc::numSummary(cum_tulos_space[,c("MCC","F1","TPR","FPR","PPV")])[[2]],4)




###mgm

library(devtools)
install_github("jmbh/mgm")
library(mgm)


ts_sim_data_100p100n.1_c <- ts_sim_data_100p100n.1[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.1_c <- cbind(ts_sim_data_100p100n.1_c,ts_sim_data_100p100n.1[[i]])
}

mgm_c_cv <- tvmgm(data =  t(ts_sim_data_100p100n.1_c),
                  type = c(rep("g",100)),
                  level = rep(1,100),
                  k = 2,
                  estpoints = seq(0, 1, length=10),
                  bandwidth = .1,
                  lambdaSel = "CV",
                  ruleReg = "AND",
                  pbar = TRUE,
                  overparameterize = T,
                  signInfo = FALSE)


mgm_c_cv$interactions$weights
mgm_c_cv$pairwise$wadj


mgm_c <- mgm_c_cv$pairwise$wadj
mgm_c[mgm_c!=0] <- 1

mgm_c.1 <- mgm_c_cv$pairwise$wadj
mgm_c.1[mgm_c.1!=0] <- 1



par(mfrow=c(1,3))
graph_plot(mvar_c[,,1])
graph_plot(mvar_c[,,2])
graph_plot(mvar_c[,,3])

calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[1]],mgm_c[,,1] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[2]],mgm_c[,,2] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,3] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,4] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,5] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,6] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,7] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,8] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,9] )) 
calculate_scores(similarity_stats(ts_true_data_100p_500n[[1]][[3]],mgm_c[,,10] )) 


similarity_plots(ts_true_data_100p_500n[[1]][[1]],mgm_c[,,1])


mgm_res2list <- function(result) {
  asdf <- list()
  for (i in 1:dim(result)[3]) {
    asdf[[i]] <- result[,,i]
  }
  return(asdf)
}


mgm_cs.1 <- ts_scores(ts_true_data_100p_500n[[1]], mgm_res2list(mgm_c.1),10); mgm_cs.1




#2

ts_sim_data_100p100n.2_c <- ts_sim_data_100p100n.2[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.2_c <- cbind(ts_sim_data_100p100n.2_c,ts_sim_data_100p100n.2[[i]])
}

mgm_c_cv.2 <- tvmgm(data =  t(ts_sim_data_100p100n.2_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.2 <- mgm_c_cv.2$pairwise$wadj
mgm_c.2[mgm_c.2!=0] <- 1

mgm_cs.2 <- ts_scores(ts_true_data_100p_500n[[2]], mgm_res2list(mgm_c.2),10); mgm_cs.2




#3

ts_sim_data_100p100n.3_c <- ts_sim_data_100p100n.3[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.3_c <- cbind(ts_sim_data_100p100n.3_c,ts_sim_data_100p100n.3[[i]])
}

mgm_c_cv.3 <- tvmgm(data =  t(ts_sim_data_100p100n.3_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.3 <- mgm_c_cv.3$pairwise$wadj
mgm_c.3[mgm_c.3!=0] <- 1

mgm_cs.3 <-  ts_scores(ts_true_data_100p_500n[[3]], mgm_res2list(mgm_c.3),10);mgm_cs.3



#4

ts_sim_data_100p100n.4_c <- ts_sim_data_100p100n.4[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.4_c <- cbind(ts_sim_data_100p100n.4_c,ts_sim_data_100p100n.4[[i]])
}

mgm_c_cv.4 <- tvmgm(data =  t(ts_sim_data_100p100n.4_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.4 <- mgm_c_cv.4$pairwise$wadj
mgm_c.4[mgm_c.4!=0] <- 1

mgm_cs.4 <-  ts_scores(ts_true_data_100p_500n[[4]], mgm_res2list(mgm_c.4),10);mgm_cs.4


#5

ts_sim_data_100p100n.5_c <- ts_sim_data_100p100n.5[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.5_c <- cbind(ts_sim_data_100p100n.5_c,ts_sim_data_100p100n.5[[i]])
}

mgm_c_cv.5 <- tvmgm(data =  t(ts_sim_data_100p100n.5_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.5 <- mgm_c_cv.5$pairwise$wadj
mgm_c.5[mgm_c.5!=0] <- 1

mgm_cs.5 <-  ts_scores(ts_true_data_100p_500n[[5]], mgm_res2list(mgm_c.5),10);mgm_cs.5



#6

ts_sim_data_100p100n.6_c <- ts_sim_data_100p100n.6[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.6_c <- cbind(ts_sim_data_100p100n.6_c,ts_sim_data_100p100n.6[[i]])
}

mgm_c_cv.6 <- tvmgm(data =  t(ts_sim_data_100p100n.6_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.6 <- mgm_c_cv.6$pairwise$wadj
mgm_c.6[mgm_c.6!=0] <- 1

mgm_cs.6 <-  ts_scores(ts_true_data_100p_500n[[6]], mgm_res2list(mgm_c.6),10);mgm_cs.6



#7

ts_sim_data_100p100n.7_c <- ts_sim_data_100p100n.7[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.7_c <- cbind(ts_sim_data_100p100n.7_c,ts_sim_data_100p100n.7[[i]])
}

mgm_c_cv.7 <- tvmgm(data =  t(ts_sim_data_100p100n.7_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.7 <- mgm_c_cv.7$pairwise$wadj
mgm_c.7[mgm_c.7!=0] <- 1

mgm_cs.7 <-  ts_scores(ts_true_data_100p_500n[[7]], mgm_res2list(mgm_c.7),10);mgm_cs.7



#8

ts_sim_data_100p100n.8_c <- ts_sim_data_100p100n.8[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.8_c <- cbind(ts_sim_data_100p100n.8_c,ts_sim_data_100p100n.8[[i]])
}

mgm_c_cv.8 <- tvmgm(data =  t(ts_sim_data_100p100n.8_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.8 <- mgm_c_cv.8$pairwise$wadj
mgm_c.8[mgm_c.8!=0] <- 1

mgm_cs.8 <-  ts_scores(ts_true_data_100p_500n[[8]], mgm_res2list(mgm_c.8),10);mgm_cs.8



#9

ts_sim_data_100p100n.9_c <- ts_sim_data_100p100n.9[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.9_c <- cbind(ts_sim_data_100p100n.9_c,ts_sim_data_100p100n.9[[i]])
}

mgm_c_cv.9 <- tvmgm(data =  t(ts_sim_data_100p100n.9_c),
                    type = c(rep("g",100)),
                    level = rep(1,100),
                    k = 2,
                    estpoints = seq(0, 1, length=10),
                    bandwidth = .1,
                    lambdaSel = "CV",
                    ruleReg = "AND",
                    pbar = TRUE,
                    overparameterize = T,
                    signInfo = FALSE)


mgm_c.9 <- mgm_c_cv.9$pairwise$wadj
mgm_c.9[mgm_c.9!=0] <- 1

mgm_cs.9 <-  ts_scores(ts_true_data_100p_500n[[9]], mgm_res2list(mgm_c.9),10); mgm_cs.9


#10

ts_sim_data_100p100n.10_c <- ts_sim_data_100p100n.10[[1]]
for (i in 2:10) {
  ts_sim_data_100p100n.10_c <- cbind(ts_sim_data_100p100n.10_c,ts_sim_data_100p100n.10[[i]])
}

mgm_c_cv.10 <- tvmgm(data =  t(ts_sim_data_100p100n.10_c),
                     type = c(rep("g",100)),
                     level = rep(1,100),
                     k = 2,
                     estpoints = seq(0, 1, length=10),
                     bandwidth = .1,
                     lambdaSel = "CV",
                     ruleReg = "AND",
                     pbar = TRUE,
                     overparameterize = T,
                     signInfo = FALSE)


mgm_c.10 <- mgm_c_cv.10$pairwise$wadj
mgm_c.10[mgm_c.10!=0] <- 1

mgm_cs.10 <-  ts_scores(ts_true_data_100p_500n[[10]], mgm_res2list(mgm_c.10),10);mgm_cs.10




cum_tulos_mgm <- mgm_cs.1

for (i in 2:10) {
  cum_tulos_mgm <- rbind(cum_tulos_mgm, eval(parse(text=paste0("mgm_cs.",i))))
}

RcmdrMisc::numSummary(cum_tulos_mgm[,c("MCC","F1","TPR","FPR","PPV")])
round(RcmdrMisc::numSummary(cum_tulos_mgm[,c("MCC","F1","TPR","FPR","PPV")])[[2]],4)





#stabjgl

remotes::install_github("camiling/stabJGL", dependencies = TRUE)


#1

ts_sim_data_100p100n.1t <- list(); ts_sim_data_100p100n.1t[[1]] <- t(ts_sim_data_100p100n.1[[1]])
for (i in 2:10) {
  ts_sim_data_100p100n.1t[[i]] <- t(ts_sim_data_100p100n.1[[i]])
}

stab_sim_data_100p100n.1 <-  stabJGL::stabJGL(ts_sim_data_100p100n.1t,nCores = 20,lambda2.max = 0.3)

stab_sim_data_100p100n_est.1 <- list(); stab_sim_data_100p100n_est.1[[1]] <- stab_sim_data_100p100n.1$opt.fit[[1]] !=0

for (i in 2:10) {
  stab_sim_data_100p100n_est.1[[i]] <- stab_sim_data_100p100n.1$opt.fit[[i]] !=0
}

for (i in 1:10) {
  diag(stab_sim_data_100p100n_est.1[[i]]) <- 0
}

stab_tulos.1 <- ts_scores(ts_true_data_100p_500n[[1]],stab_sim_data_100p100n_est.1,10)

stab_sim_data_100p100n.1$opt.sparsities #0.01878788 0.01878788 0.01878788 0.01878788 0.01878788 0.01898990 0.01898990 0.01898990 0.01898990 0.01878788
#stab_sim_data_100p100n.1$opt.lambda2 0.03157895
#stab_sim_data_100p100n.1$opt.lambda1 0.1663158

#2

ts_sim_data_100p100n.2t <- list(); ts_sim_data_100p100n.2t[[1]] <- t(ts_sim_data_100p100n.2[[1]])
for (i in 2:10) {
  ts_sim_data_100p100n.2t[[i]] <- t(ts_sim_data_100p100n.2[[i]])
}

pt.1 <- Sys.time()
stab_sim_data_100p100n.2 <-  stabJGL::stabJGL(ts_sim_data_100p100n.2t,nCores = 8,lambda2.max = 0.1,lambda1.max = 0.5)
Sys.time() - pt.1
#11.41195 hours

stab_sim_data_100p100n_est.2 <- list(); stab_sim_data_100p100n_est.2[[1]] <- stab_sim_data_100p100n.2$opt.fit[[1]] !=0

for (i in 2:10) {
  stab_sim_data_100p100n_est.2[[i]] <- stab_sim_data_100p100n.2$opt.fit[[i]] !=0
}

for (i in 1:10) {
  diag(stab_sim_data_100p100n_est.2[[i]]) <- 0
}

stab_tulos.2 <- ts_scores(ts_true_data_100p_500n[[2]],stab_sim_data_100p100n_est.2,10)

stab_sim_data_100p100n.2$opt.sparsities #0.01979798 0.01979798 0.01979798 0.02000000 0.02000000 0.01979798 0.01979798 0.01979798 0.02020202 0.02040404
stab_sim_data_100p100n.2$opt.lambda1  #0.1389474
stab_sim_data_100p100n.2$opt.lambda2  #0.02631579


#etc...

cum_tulos_stab <-stab_tulos.1

for (i in 2:10) {
  cum_tulos_stab <- rbind(cum_tulos_stab, eval(parse(text=paste0("stab_tulos.",i))) )
}

RcmdrMisc::numSummary(cum_tulos_stab[,c("MCC","F1","TPR","FPR","PPV")])
round(RcmdrMisc::numSummary(cum_tulos_stab[,c("MCC","F1","TPR","FPR","PPV")])[[2]],4)


