TVGL <- function(X, p, lambda1 = 0.1, lambda2 = 0.1, transpose = TRUE, true_adj, summarise = FALSE){
  
  Tt <- length(X)
  
  for(i in 1:Tt){
    
    assign(paste0("omega", i), 
           CVXR::Variable(p, p, PSD = TRUE))
    if(transpose==TRUE){
      assign(paste0("S", i), 
             cov(t(X[[i]])))
    }else{
      assign(paste0("S", i), 
             cov(X[[i]]))
    }
    
  }
  
  obj_text <- paste0("CVXR::log_det(omega1) - CVXR::matrix_trace(S1 %*% omega1) - lambda1 * sum(abs(omega1[lower.tri(omega1)])) * 2")
  
  for(i in 2:Tt){
    
    obj_text <- paste0(obj_text, 
                       " + CVXR::log_det(omega", i, ") - CVXR::matrix_trace(S", i, "%*% omega", i, ") - lambda1 * sum(abs(omega", i, "[lower.tri(omega", i, ")])) * 2 - lambda2 * sum(abs(omega", i, "[lower.tri(omega", i, ")]-omega", i-1, "[lower.tri(omega", i-1, ")])) * 2")
    
  }
  
  obj <- eval(parse(text = obj_text))
  
  prob <- CVXR::Problem(Maximize(obj))
  
  result <- CVXR::solve(prob, solver = "SCS")
  
  Omega_est <- list()
  
  for(i in 1:Tt){
    
    res <- paste0("result$getValue(omega", i, ")")
    
    Omega_est[[i]] <- eval(parse(text = res))
    
  }
  
  if (summarise == FALSE){
    return(list(res = result, omega = Omega_est))  
  }else{
    return(list(scores = ts_scores(true_adj, omega2adjancy(Omega_est)), MLE = result$value) )
  }
  
  gc()
}


omega2adjancy <- function(res, rounded = 3){
  adj_list <- list()
  tt <- length(res)
  
  for (i in 1:tt){
    theta <- round(res[[i]], 3)
    theta[theta != 0] <- 1
    diag(theta) <- 0
    
    adj_list[[i]] <- theta
  }
  
  return(adj_list)
}


set_lambda <- function(data_list,true_adj_list,p,lambda1_range,lambda2_range){
  
  results_list <- list()
  N <- length(lambda1_range)
  M <- length(lambda2_range)
  index <- 1
  for (i in 1:N) {
    for (j in 1:M) {
      results_list[[index]] <- TVGL(data_list,p=p,lambda1 = lambda1_range[i],lambda2 = lambda2_range[j], true_adj = true_adj_list,summarise = TRUE)
      index = index + 1
    }
  }
  return(results_list)
}


